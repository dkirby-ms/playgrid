import { Users } from "lucide-react";
import { ImageWithFallback } from "./figma/ImageWithFallback";

interface GameTileProps {
  name: string;
  image: string;
  players: string;
  activeGames: number;
  onSelect: () => void;
}

export function GameTile({ name, image, players, activeGames, onSelect }: GameTileProps) {
  return (
    <button
      onClick={onSelect}
      className="group relative overflow-hidden rounded-xl bg-zinc-800 transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-violet-500/20"
    >
      <div className="aspect-[4/3] overflow-hidden">
        <ImageWithFallback
          src={image}
          alt={name}
          className="size-full object-cover transition-transform duration-300 group-hover:scale-110"
        />
      </div>
      <div className="absolute inset-0 bg-gradient-to-t from-black/90 via-black/50 to-transparent" />
      <div className="absolute bottom-0 left-0 right-0 p-4">
        <h3 className="text-xl mb-2 text-white">{name}</h3>
        <div className="flex items-center justify-between text-sm text-zinc-300">
          <span className="flex items-center gap-1">
            <Users className="size-4" />
            {players}
          </span>
          <span className="text-violet-400">{activeGames} active</span>
        </div>
      </div>
    </button>
  );
}
