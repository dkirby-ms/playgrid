import { Clock, Users, Play } from "lucide-react";

interface ActiveGame {
  id: string;
  gameName: string;
  players: string[];
  maxPlayers: number;
  status: "waiting" | "in-progress";
  timeElapsed?: string;
}

interface ActiveGamesListProps {
  games: ActiveGame[];
  onJoinGame: (gameId: string) => void;
}

export function ActiveGamesList({ games, onJoinGame }: ActiveGamesListProps) {
  return (
    <div className="rounded-xl bg-zinc-800/50 p-4 backdrop-blur-sm">
      <h2 className="mb-4 text-lg text-white">Active Games</h2>
      <div className="space-y-3">
        {games.map((game) => (
          <div
            key={game.id}
            className="rounded-lg bg-zinc-900/50 p-3 border border-zinc-700/50 hover:border-violet-500/50 transition-colors"
          >
            <div className="flex items-start justify-between mb-2">
              <div className="flex-1">
                <h3 className="text-white mb-1">{game.gameName}</h3>
                <div className="flex items-center gap-3 text-xs text-zinc-400">
                  <span className="flex items-center gap-1">
                    <Users className="size-3" />
                    {game.players.length}/{game.maxPlayers}
                  </span>
                  {game.status === "in-progress" && game.timeElapsed && (
                    <span className="flex items-center gap-1">
                      <Clock className="size-3" />
                      {game.timeElapsed}
                    </span>
                  )}
                </div>
              </div>
              <span
                className={`rounded-full px-2 py-0.5 text-xs ${
                  game.status === "waiting"
                    ? "bg-amber-500/20 text-amber-400"
                    : "bg-green-500/20 text-green-400"
                }`}
              >
                {game.status === "waiting" ? "Waiting" : "Playing"}
              </span>
            </div>
            <div className="flex items-center justify-between">
              <div className="flex -space-x-2">
                {game.players.map((player, idx) => (
                  <div
                    key={idx}
                    className="size-6 rounded-full bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center text-xs text-white border-2 border-zinc-900"
                    title={player}
                  >
                    {player.charAt(0)}
                  </div>
                ))}
              </div>
              {game.status === "waiting" && game.players.length < game.maxPlayers && (
                <button
                  onClick={() => onJoinGame(game.id)}
                  className="flex items-center gap-1 rounded-md bg-violet-600 px-3 py-1 text-xs text-white transition-colors hover:bg-violet-700"
                >
                  <Play className="size-3" />
                  Join
                </button>
              )}
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
