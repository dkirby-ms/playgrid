import { Circle } from "lucide-react";

interface Player {
  id: string;
  name: string;
  status: "online" | "in-game" | "away";
  avatar: string;
}

interface OnlinePlayersListProps {
  players: Player[];
}

export function OnlinePlayersList({ players }: OnlinePlayersListProps) {
  const statusColors = {
    online: "bg-green-500",
    "in-game": "bg-amber-500",
    away: "bg-zinc-500",
  };

  return (
    <div className="rounded-xl bg-zinc-800/50 p-4 backdrop-blur-sm">
      <h2 className="mb-4 flex items-center justify-between text-lg text-white">
        Online Players
        <span className="rounded-full bg-violet-600 px-2.5 py-0.5 text-sm">
          {players.filter((p) => p.status === "online").length}
        </span>
      </h2>
      <div className="space-y-2">
        {players.map((player) => (
          <div
            key={player.id}
            className="flex items-center gap-3 rounded-lg bg-zinc-900/50 p-2 transition-colors hover:bg-zinc-900"
          >
            <div className="relative">
              <div className="size-10 rounded-full bg-gradient-to-br from-violet-500 to-purple-600 flex items-center justify-center text-white">
                {player.name.charAt(0)}
              </div>
              <Circle
                className={`absolute -bottom-0.5 -right-0.5 size-3 rounded-full border-2 border-zinc-800 ${statusColors[player.status]}`}
                fill="currentColor"
              />
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm text-white truncate">{player.name}</p>
              <p className="text-xs text-zinc-400 capitalize">{player.status}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
