import { Gamepad2, LogOut, Settings, User } from "lucide-react";
import { GameTile } from "./components/GameTile";
import { OnlinePlayersList } from "./components/OnlinePlayersList";
import { ActiveGamesList } from "./components/ActiveGamesList";

export default function App() {
  const games = [
    {
      id: "1",
      name: "Risk",
      image: "https://images.unsplash.com/photo-1606503153255-59d8b8b82176?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxyaXNrJTIwYm9hcmQlMjBnYW1lfGVufDF8fHx8MTc3MzUyNDMwOHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      players: "2-6",
      activeGames: 8,
    },
    {
      id: "2",
      name: "Backgammon",
      image: "https://images.unsplash.com/photo-1559480423-85de1db621ed?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxiYWNrZ2FtbW9uJTIwYm9hcmQlMjBnYW1lfGVufDF8fHx8MTc3MzUyNDMwOXww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      players: "2",
      activeGames: 12,
    },
    {
      id: "3",
      name: "Checkers",
      image: "https://images.unsplash.com/photo-1716418927483-fb7fa17ea7f9?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjaGVja2VycyUyMGJvYXJkJTIwZ2FtZXxlbnwxfHx8fDE3NzM1MjQzMDl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      players: "2",
      activeGames: 5,
    },
    {
      id: "4",
      name: "Hungry Hungry Hippos",
      image: "https://images.unsplash.com/photo-1655087751252-8d29e1bb6b32?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxoaXBwbyUyMHRveSUyMGdhbWUlMjBjb2xvcmZ1bHxlbnwxfHx8fDE3NzM1MjQ1NTJ8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      players: "2-4",
      activeGames: 9,
    },
    {
      id: "5",
      name: "Catan",
      image: "https://images.unsplash.com/photo-1606733847546-db8546099013?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXRhbiUyMGJvYXJkJTIwZ2FtZXxlbnwxfHx8fDE3NzM1MjQ1NDl8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      players: "3-4",
      activeGames: 7,
    },
    {
      id: "6",
      name: "Scrabble",
      image: "https://images.unsplash.com/photo-1720236177709-6048d149d426?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzY3JhYmJsZSUyMGJvYXJkJTIwZ2FtZXxlbnwxfHx8fDE3NzM1MjQzMTB8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral",
      players: "2-4",
      activeGames: 4,
    },
  ];

  const onlinePlayers = [
    { id: "1", name: "Sarah Chen", status: "online" as const, avatar: "SC" },
    { id: "2", name: "Mike Johnson", status: "in-game" as const, avatar: "MJ" },
    { id: "3", name: "Emma Davis", status: "online" as const, avatar: "ED" },
    { id: "4", name: "Alex Rivera", status: "in-game" as const, avatar: "AR" },
    { id: "5", name: "Chris Taylor", status: "online" as const, avatar: "CT" },
    { id: "6", name: "Olivia Brown", status: "away" as const, avatar: "OB" },
    { id: "7", name: "James Wilson", status: "online" as const, avatar: "JW" },
    { id: "8", name: "Sophia Martinez", status: "in-game" as const, avatar: "SM" },
  ];

  const activeGames = [
    {
      id: "1",
      gameName: "Chess Championship",
      players: ["Mike Johnson", "Alex Rivera"],
      maxPlayers: 2,
      status: "in-progress" as const,
      timeElapsed: "12m",
    },
    {
      id: "2",
      gameName: "Risk: World Domination",
      players: ["Sophia Martinez", "Emma Davis", "Chris Taylor"],
      maxPlayers: 6,
      status: "waiting" as const,
    },
    {
      id: "3",
      gameName: "Backgammon Battle",
      players: ["Sarah Chen"],
      maxPlayers: 2,
      status: "waiting" as const,
    },
    {
      id: "4",
      gameName: "Monopoly Madness",
      players: ["James Wilson", "Olivia Brown", "Mike Johnson", "Alex Rivera"],
      maxPlayers: 8,
      status: "in-progress" as const,
      timeElapsed: "45m",
    },
  ];

  const handleSelectGame = (gameId: string) => {
    console.log("Selected game:", gameId);
  };

  const handleJoinGame = (gameId: string) => {
    console.log("Joining game:", gameId);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-zinc-900 via-zinc-900 to-violet-950">
      {/* Header */}
      <header className="border-b border-zinc-800 bg-zinc-900/50 backdrop-blur-sm">
        <div className="mx-auto max-w-7xl px-6 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div className="rounded-lg bg-gradient-to-br from-violet-600 to-purple-600 p-2">
                <Gamepad2 className="size-6 text-white" />
              </div>
              <div>
                <h1 className="text-xl text-white">Board Game Lounge</h1>
                <p className="text-sm text-zinc-400">Play with friends worldwide</p>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button className="rounded-lg bg-zinc-800 p-2 text-zinc-400 transition-colors hover:bg-zinc-700 hover:text-white">
                <Settings className="size-5" />
              </button>
              <button className="flex items-center gap-2 rounded-lg bg-zinc-800 px-4 py-2 text-zinc-400 transition-colors hover:bg-zinc-700 hover:text-white">
                <User className="size-5" />
                <span className="text-sm">Player123</span>
              </button>
              <button className="rounded-lg bg-zinc-800 p-2 text-zinc-400 transition-colors hover:bg-zinc-700 hover:text-white">
                <LogOut className="size-5" />
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="mx-auto max-w-7xl px-6 py-8">
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-3">
          {/* Game Library - Takes 2 columns on large screens */}
          <div className="lg:col-span-2">
            <h2 className="mb-4 text-2xl text-white">Game Library</h2>
            <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
              {games.map((game) => (
                <GameTile
                  key={game.id}
                  name={game.name}
                  image={game.image}
                  players={game.players}
                  activeGames={game.activeGames}
                  onSelect={() => handleSelectGame(game.id)}
                />
              ))}
            </div>
          </div>

          {/* Sidebar - Takes 1 column on large screens */}
          <div className="space-y-6">
            <ActiveGamesList games={activeGames} onJoinGame={handleJoinGame} />
            <OnlinePlayersList players={onlinePlayers} />
          </div>
        </div>
      </div>
    </div>
  );
}